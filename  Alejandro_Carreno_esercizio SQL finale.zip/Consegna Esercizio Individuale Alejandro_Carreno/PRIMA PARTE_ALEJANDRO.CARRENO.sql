CREATE SCHEMA ToysGroup;

-- Category
CREATE TABLE ToysGroup.Category (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL
);

-- Product
CREATE TABLE ToysGroup.Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    CategoryID INT  REFERENCES ToysGroup.Category(CategoryID)
);

-- SalesRegion
CREATE TABLE ToysGroup.SalesRegion (
    SalesRegionID INT PRIMARY KEY,
    SalesRegionName VARCHAR(100) NOT NULL
);

-- Country
CREATE TABLE ToysGroup.Country (
    CountryID INT PRIMARY KEY,
    CountryName VARCHAR(100) NOT NULL,
    SalesRegionID INT REFERENCES ToysGroup.SalesRegion(SalesRegionID)
);

-- Sales
CREATE TABLE ToysGroup.Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT  REFERENCES ToysGroup.Product(ProductID),
    CountryID INT  REFERENCES ToysGroup.Country(CountryID),
    SalesDate DATE,
    Quantity INT,
    Revenue DECIMAL(10,2)
);

-- Popolamento tabelle




-- Categorie
INSERT INTO Category VALUES
(1, 'Bikes'),
(2, 'Clothing'),
(3, 'Board Games'),
(4, 'Electronics'),
(5, 'Action Figures'),
(6, 'Educational Toys'),
(7, 'Outdoor Toys'),
(8, 'Building Sets');

-- Prodotti
INSERT INTO Product VALUES
(101, 'Bikes-100', 1),
(102, 'Bikes-200', 1),
(201, 'Bike Glove M', 2),
(202, 'Bike Glove L', 2),
(301, 'Chess Deluxe', 3),
(302, 'Monopoly Classic', 3),
(401, 'RC Car Turbo', 4),
(402, 'Drone MiniX', 4),
(501, 'SuperHero Alpha', 5),
(601, 'Math Puzzle Box', 6),
(701, 'Water Gun Max', 7),
(801, 'Lego Space Set', 8);



-- Regioni
INSERT INTO SalesRegion VALUES
(1, 'WestEurope'),
(2, 'SouthEurope'),
(3, 'NorthAmerica'),
(4, 'AsiaPacific');

-- Stati
INSERT INTO Country VALUES
(10, 'France', 1),
(11, 'Germany', 1),
(12, 'Italy', 2),
(13, 'Greece', 2),
(14, 'USA', 3),
(15, 'Canada', 3),
(16, 'Japan', 4),
(17, 'Australia', 4);

-- Vendite
INSERT INTO Sales VALUES

(3001, 101, 10, '2020-03-15', 60, 3000.00),
(3002, 201, 12, '2020-05-20', 50, 1250.00),
(3003, 301, 11, '2020-07-10', 45, 1550.00),
(3004, 401, 13, '2020-10-05', 30, 4500.00),
(3101, 102, 10, '2021-02-18', 80, 4000.00),
(3102, 302, 14, '2021-06-12', 70, 3500.00),
(3103, 402, 11, '2021-09-23', 25, 3750.00),
(3104, 501, 12, '2021-11-29', 60, 2400.00),
(3201, 601, 15, '2022-01-09', 50, 1500.00),
(3202, 701, 13, '2022-04-20', 75, 2250.00),
(3203, 801, 17, '2022-08-07', 90, 8100.00),
(3204, 101, 16, '2022-12-14', 55, 2750.00),
(3301, 101, 10, '2023-03-15', 80, 4000.00),
(3302, 201, 12, '2023-06-20', 60, 1500.00),
(3303, 301, 13, '2023-08-05', 45, 1600.00),
(3304, 501, 14, '2023-10-10', 70, 2800.00),
(3305, 801, 15, '2023-12-25', 90, 8100.00),
(3401, 102, 11, '2024-01-08', 100, 5000.00),
(3402, 401, 11, '2024-05-22', 70, 10500.00),
(3403, 601, 16, '2024-07-14', 55, 1650.00),
(3404, 701, 17, '2024-09-01', 65, 1950.00),
(3405, 302, 13, '2024-11-11', 50, 2500.00),
(3501, 101, 10, '2025-01-01', 100, 5000.00),
(3502, 102, 11, '2025-01-05', 120, 6000.00),
(3503, 201, 12, '2025-01-07', 90, 2250.00),
(3504, 301, 13, '2025-01-10', 50, 1750.00),
(3505, 302, 10, '2025-01-12', 40, 2000.00),
(3506, 401, 12, '2025-01-14', 30, 4500.00),
(3507, 402, 11, '2025-01-16', 25, 3750.00),
(3508, 501, 13, '2025-01-18', 80, 3200.00),
(3509, 601, 10, '2025-01-20', 60, 1800.00),
(3510, 701, 12, '2025-01-22', 100, 3000.00),
(3511, 801, 11, '2025-01-24', 70, 6300.00),
(3512, 302, 14, '2025-01-25', 90, 4500.00),
(3513, 101, 15, '2025-01-27', 55, 2750.00),
(3514, 601, 16, '2025-01-28', 60, 2400.00),
(3515, 701, 17, '2025-01-30', 75, 2250.00);