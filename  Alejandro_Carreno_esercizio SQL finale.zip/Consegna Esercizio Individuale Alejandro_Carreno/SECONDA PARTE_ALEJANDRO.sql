/* 1)	Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare
 l’univocità dei valori di ciascuna PK (una query per tabella implementata).
 */
 SELECT CategoryID, COUNT(*) as verifica
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

SELECT ProductID, COUNT(*) as verifica
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT SalesRegionID, COUNT(*) as verifica
FROM SalesRegion
GROUP BY SalesRegionID
HAVING COUNT(*) > 1;

SELECT CountryID, COUNT(*) as verifica
FROM Country
GROUP BY CountryID
HAVING COUNT(*) > 1;

SELECT SalesID, COUNT(*) as verifica
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;



/*
2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, 
la data, il nome del prodotto, la categoria del prodotto,il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione 
 che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
 
 */
 
 SELECT
  s.SalesID AS codice_documento,
  s.SalesDate AS data_vendita,
  p.ProductName AS nome_prodotto,
  cat.CategoryName AS categoria,
  co.CountryName AS stato,
  r.SalesRegionName AS regione,
  CASE
    WHEN DATEDIFF(CURDATE(), s.SalesDate) > 180 THEN TRUE
    ELSE FALSE
  END AS oltre_180_giorni
FROM Sales s
JOIN Product p 
    ON s.ProductID = p.ProductID
JOIN Category cat
    ON p.CategoryID = cat.CategoryID
JOIN Country co 
    ON s.CountryID = co.CountryID
JOIN SalesRegion r 
    ON co.SalesRegionID = r.SalesRegionID
ORDER BY s.SalesDate;




-- esercizio 3

WITH AnnoUltimo AS (
    SELECT MAX(YEAR(SalesDate)) AS ultimo_anno
    FROM Sales s 
),


MediaUltimoAnno AS (
    SELECT AVG(s.Quantity) AS media
    FROM Sales s 
    WHERE YEAR(SalesDate) = (SELECT ultimo_anno FROM AnnoUltimo)
),


TotaliPerProdotto AS (
    SELECT ProductID, SUM(s.Quantity) AS totale
    FROM Sales s
    GROUP BY ProductID
)


SELECT t.ProductID, t.totale
FROM TotaliPerProdotto t
JOIN MediaUltimoAnno m ON t.totale > m.media;



-- ES 4

SELECT
  p.ProductID,
  p.ProductName,
  YEAR(s.SalesDate) AS anno,
  SUM(s.Revenue) AS fatturato_totale
FROM Sales s
JOIN Product p 
     ON s.ProductID = p.ProductID
GROUP BY p.ProductID, p.ProductName, anno
ORDER BY anno, fatturato_totale DESC;



-- es 5 

SELECT
  c.CountryName,
  YEAR(s.SalesDate) AS anno,
  SUM(s.Revenue) AS fatturato
FROM Sales s
JOIN Country c ON s.CountryID = c.CountryID
GROUP BY c.CountryName, anno
ORDER BY anno, fatturato DESC;

-- esercizio 6

SELECT
  cat.CategoryName,
  SUM(s.Quantity) AS totale_venduto
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category cat ON p.CategoryID = cat.CategoryID
GROUP BY cat.CategoryName
ORDER BY totale_venduto DESC
LIMIT 1;



-- ES 7 approcio 1 
SELECT *
FROM Product
WHERE ProductID NOT IN (
    SELECT DISTINCT ProductID FROM Sales
);

-- ES 7 approccio 2
SELECT p.*
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.SalesID IS NULL;


/* ES 8 La vista deve contenere:
	•	ProductID (codice prodotto)
	•	ProductName (nome prodotto)
	•	CategoryName (nome della categoria, proveniente dalla tabella Category)
*/

CREATE VIEW v_prodotti_denormalizzati AS
SELECT
  p.ProductID,
  p.ProductName,
  c.CategoryName
FROM Product p
JOIN Category c ON p.CategoryID = c.CategoryID;

SELECT * FROM v_prodotti_denormalizzati;


-- ES 9

CREATE VIEW v_info_geografiche AS
SELECT
  co.CountryID,
  co.CountryName,
  r.SalesRegionName
FROM Country co
JOIN SalesRegion r ON co.SalesRegionID = r.SalesRegionID;

SELECT * FROM v_info_geografiche;


-- Es 10  aggiuntivo di analisi vendite anno 2024 vs 2025 

WITH Vendite2024 AS (
  SELECT ProductID, SUM(Quantity) AS qty_2024
  FROM Sales
  WHERE YEAR(SalesDate) = 2024
  GROUP BY ProductID
),
Vendite2025 AS (
  SELECT ProductID, SUM(Quantity) AS qty_2025
  FROM Sales
  WHERE YEAR(SalesDate) = 2025
  GROUP BY ProductID
)

SELECT 
  p.ProductID,
  p.ProductName,
  COALESCE(v24.qty_2024, 0) AS quantita_2024,
  COALESCE(v25.qty_2025, 0) AS quantita_2025,
  (COALESCE(v25.qty_2025, 0) - COALESCE(v24.qty_2024, 0)) AS differenza,
  CASE 
    WHEN COALESCE(v24.qty_2024, 0) = 0 THEN 'N/A'
    ELSE CONCAT(ROUND(((v25.qty_2025 - v24.qty_2024) / v24.qty_2024) * 100, 2), '%')
  END AS variazione_percentuale
FROM Product p
LEFT JOIN Vendite2024 v24 ON p.ProductID = v24.ProductID
LEFT JOIN Vendite2025 v25 ON p.ProductID = v25.ProductID
ORDER BY variazione_percentuale DESC;


-- Es 11 aggiuntivo per Trovare i paesi che hanno avuto crescita 
-- del fatturato per tre anni consecutivi.


WITH FatturatoPerAnno AS (
  SELECT
    c.CountryName,
    YEAR(s.SalesDate) AS anno,
    SUM(s.Revenue) AS fatturato
  FROM Sales s
  JOIN Country c 
      ON s.CountryID = c.CountryID
  GROUP BY c.CountryName, anno
),
FatturatoConTrend AS (
  SELECT *,
         LAG(fatturato, 1) OVER (PARTITION BY CountryName ORDER BY anno) AS prev1,
         LAG(fatturato, 2) OVER (PARTITION BY CountryName ORDER BY anno) AS prev2
  FROM FatturatoPerAnno
)

SELECT CountryName, anno, fatturato
FROM FatturatoConTrend
WHERE fatturato > prev1 AND prev1 > prev2;






-- ES 12 aggiuntivo
/* Calcolare il fatturato per regione e fascia di fatturato (Low, Medium, High) in base al valore medio per prodotto
	•	Le fasce sono definite dinamicamente con CASE:
	•	Low: < 2000 €
	•	Medium: 2000–5000 €
	•	High: > 5000 €
    */
    

SELECT
  geo.SalesRegionName AS regione,
  vendite.fascia,
  COUNT(*) AS numero_prodotti,
  ROUND(AVG(vendite.fatturato_prodotto), 2) AS media_fatturato
FROM (
    SELECT
      p.ProductID,
      p.ProductName,
      SUM(s.Revenue) AS fatturato_prodotto,
      CASE
        WHEN SUM(s.Revenue) < 2000 THEN 'Low'
        WHEN SUM(s.Revenue) BETWEEN 2000 AND 5000 THEN 'Medium'
        ELSE 'High'
      END AS fascia,
      c.CountryID
    FROM Sales s
    JOIN Product p 
        ON s.ProductID = p.ProductID
    JOIN Country c 
        ON s.CountryID = c.CountryID
    GROUP BY p.ProductID, p.ProductName, c.CountryID
) AS vendite
JOIN (
    SELECT co.CountryID, r.SalesRegionName
    FROM Country co
    JOIN SalesRegion r 
        ON co.SalesRegionID = r.SalesRegionID
) AS geo 
     ON vendite.CountryID = geo.CountryID
GROUP BY geo.SalesRegionName, vendite.fascia
ORDER BY regione, fascia;
